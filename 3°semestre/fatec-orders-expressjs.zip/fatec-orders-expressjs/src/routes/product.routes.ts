import express from "express";
import { Request, Response } from "express";
import { IproductListFilters } from "../../Iproducts";


const router = express.Router();

const products = [
    {
        id: 1,
        name: "Feijao Carioca",
        brand: "Broto Legal",
        barCode: "99999999999999",
        supplier: "Rede de Distribuição Ltda",
        stockId: 98,
        price: 8.79,
        weight: 1,
        measureUnit: "kg",
    },
    {
        id: 2,
        name: "Arroz",
        brand: "Tio João",
        barCode: "99999999999998",
        supplier: "Rede de Distribuição Ltda",
        stockId: 65,
        price: 29.99,
        weight: 5,
        measureUnit: "kg",
    }
]

// Rota GET para listar todos os produtos com filtros
router.get("/", (req: Request, res: Response) => {
    const productFilters = req.query as unknown as IproductListFilters;
    const { name: nameFilter, brand: brandFilter, supplier: supplierFilter, stockId: stockFilter } = productFilters;

    const foundProducts = products.filter(({ name, brand, supplier, stockId }) => {
        // Se não houver filtros, retorna todos os produtos
        if (!(nameFilter || brandFilter || supplierFilter || stockFilter)) return true;

        let found = false; // Começa como false e muda para true se algum critério for atendido

        if (nameFilter && name.toUpperCase().includes(nameFilter.toUpperCase())) 
            found = true;
        if (brandFilter && brand.toUpperCase().includes(brandFilter.toUpperCase())) 
            found = true;
        if (supplierFilter && supplier.toUpperCase().includes(supplierFilter.toUpperCase())) 
            found = true;
        if (stockFilter && stockId == stockFilter) 
            found = true;

        return found;
    });

    res.status(200).json(foundProducts);
})

    //cria um produto
    router.post("/", (req: Request, res: Response) => {
        const product = req.body;
        products.push(product);

        res.status(201).send();
    });

    router.delete("/:id", (req: Request, res: Response) => {
        const { id } = req.params;

        // Verifica se o produto com o id existe
        const index = products.findIndex(product => product.id === parseInt(id));

        if (index === -1) {
            res.status(404).send({ error: "Produto não encontrado" });
            return;
        }

        // Condição para verificar se o produto não pode ser excluído
        // Exemplo: Se o produto com id 1 não puder ser excluído, podemos usar a seguinte condição:
        if (parseInt(id) === 1) {
             res.status(400).send({ error: "Este produto não pode ser excluído!" });
             return;
        }

        // Remover o produto do array
        products.splice(index, 1);

        // Retornar uma resposta de sucesso
        res.status(200).send({ message: "Produto deletado com sucesso!" });
    });

    // Rota PUT para atualizar um produto por ID
    router.put("/:id", (req: Request, res: Response) => {
        const { id } = req.params;
        const updatedProduct = req.body;

        // Encontrar o índice do produto a ser atualizado
        const index = products.findIndex(product => product.id === parseInt(id));

        if (index === -1) {
             res.status(404).send({ error: "Produto não encontrado" });
             return;
        }

        // Atualizar o produto no array
        products[index] = { ...products[index], ...updatedProduct };

        // Resposta de sucesso após atualização
        res.status(200).send({ message: "Produto atualizado com sucesso!" });
    });

export default router;